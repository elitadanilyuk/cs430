package lab9.dataTypes;

import java.util.BitSet;

public abstract class absData {

}
